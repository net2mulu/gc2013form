<?php return array (
  'last-word-table' => 'App\\Http\\Livewire\\LastWordTable',
  'lastwords' => 'App\\Http\\Livewire\\Lastwords',
  'login' => 'App\\Http\\Livewire\\Login',
  'register' => 'App\\Http\\Livewire\\Register',
);