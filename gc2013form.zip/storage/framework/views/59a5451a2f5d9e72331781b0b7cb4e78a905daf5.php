
<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from demo.holathemes.com/coursterhtml/form-register.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 04 May 2021 17:42:42 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

     <!-- Basic Page Needs
    ================================================== -->
    <title>GC-2013</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Wollo university KIOT GC-2013">

    <!-- Favicon -->
    <link href="assets/images/favicon.png" rel="icon" type="image/png">

    <!-- CSS 
    ================================================== -->
    <link rel="stylesheet" href="assets/css/uikit.css">
    <link rel="stylesheet" href="assets/css/tailwind.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/toast.css">
        <script src="assets/js/toast.js"></script>
    <!-- icons
    ================================================== -->
    <link rel="stylesheet" href="assets/css/icons.css">
 <?php echo \Livewire\Livewire::styles(); ?>

    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.8.2/dist/alpine.min.js" defer></script>
<style>
    [x-cloak] {
        display: none !important;
    }
</style>
<style>
            .la-ball-clip-rotate-pulse,
        .la-ball-clip-rotate-pulse > div {
        position: relative;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
            box-sizing: border-box;
        }
        .la-ball-clip-rotate-pulse {
        display: block;
        font-size: 0;
        color: #fff;
        }
        .la-ball-clip-rotate-pulse.la-dark {
        color: #333;
        }
        .la-ball-clip-rotate-pulse > div {
        display: inline-block;
        float: none;
        background-color: currentColor;
        border: 0 solid currentColor;
        }
        .la-ball-clip-rotate-pulse {
        width: 32px;
        height: 32px;
        }
        .la-ball-clip-rotate-pulse > div {
        position: absolute;
        top: 50%;
        left: 50%;
        border-radius: 100%;
        }
        .la-ball-clip-rotate-pulse > div:first-child {
        position: absolute;
        width: 32px;
        height: 32px;
        background: transparent;
        border-style: solid;
        border-width: 2px;
        border-right-color: transparent;
        border-left-color: transparent;
        -webkit-animation: ball-clip-rotate-pulse-rotate 1s cubic-bezier(.09, .57, .49, .9) infinite;
        -moz-animation: ball-clip-rotate-pulse-rotate 1s cubic-bezier(.09, .57, .49, .9) infinite;
        -o-animation: ball-clip-rotate-pulse-rotate 1s cubic-bezier(.09, .57, .49, .9) infinite;
            animation: ball-clip-rotate-pulse-rotate 1s cubic-bezier(.09, .57, .49, .9) infinite;
        }
        .la-ball-clip-rotate-pulse > div:last-child {
        width: 16px;
        height: 16px;
        -webkit-animation: ball-clip-rotate-pulse-scale 1s cubic-bezier(.09, .57, .49, .9) infinite;
        -moz-animation: ball-clip-rotate-pulse-scale 1s cubic-bezier(.09, .57, .49, .9) infinite;
        -o-animation: ball-clip-rotate-pulse-scale 1s cubic-bezier(.09, .57, .49, .9) infinite;
            animation: ball-clip-rotate-pulse-scale 1s cubic-bezier(.09, .57, .49, .9) infinite;
        }
        .la-ball-clip-rotate-pulse.la-sm {
        width: 16px;
        height: 16px;
        }
        .la-ball-clip-rotate-pulse.la-sm > div:first-child {
        width: 16px;
        height: 16px;
        border-width: 1px;
        }
        .la-ball-clip-rotate-pulse.la-sm > div:last-child {
        width: 8px;
        height: 8px;
        }
        .la-ball-clip-rotate-pulse.la-2x {
        width: 64px;
        height: 64px;
        }
        .la-ball-clip-rotate-pulse.la-2x > div:first-child {
        width: 64px;
        height: 64px;
        border-width: 4px;
        }
        .la-ball-clip-rotate-pulse.la-2x > div:last-child {
        width: 32px;
        height: 32px;
        }
        .la-ball-clip-rotate-pulse.la-3x {
        width: 96px;
        height: 96px;
        }
        .la-ball-clip-rotate-pulse.la-3x > div:first-child {
        width: 96px;
        height: 96px;
        border-width: 6px;
        }
        .la-ball-clip-rotate-pulse.la-3x > div:last-child {
        width: 48px;
        height: 48px;
        }
        /*
        * Animations
        */
        @-webkit-keyframes ball-clip-rotate-pulse-rotate {
        0% {
        -webkit-transform: translate(-50%, -50%) rotate(0deg);
                transform: translate(-50%, -50%) rotate(0deg);
        }
        50% {
        -webkit-transform: translate(-50%, -50%) rotate(180deg);
                transform: translate(-50%, -50%) rotate(180deg);
        }
        100% {
        -webkit-transform: translate(-50%, -50%) rotate(360deg);
                transform: translate(-50%, -50%) rotate(360deg);
        }
        }
        @-moz-keyframes ball-clip-rotate-pulse-rotate {
        0% {
        -moz-transform: translate(-50%, -50%) rotate(0deg);
            transform: translate(-50%, -50%) rotate(0deg);
        }
        50% {
        -moz-transform: translate(-50%, -50%) rotate(180deg);
            transform: translate(-50%, -50%) rotate(180deg);
        }
        100% {
        -moz-transform: translate(-50%, -50%) rotate(360deg);
            transform: translate(-50%, -50%) rotate(360deg);
        }
        }
        @-o-keyframes ball-clip-rotate-pulse-rotate {
        0% {
        -o-transform: translate(-50%, -50%) rotate(0deg);
        transform: translate(-50%, -50%) rotate(0deg);
        }
        50% {
        -o-transform: translate(-50%, -50%) rotate(180deg);
        transform: translate(-50%, -50%) rotate(180deg);
        }
        100% {
        -o-transform: translate(-50%, -50%) rotate(360deg);
        transform: translate(-50%, -50%) rotate(360deg);
        }
        }
        @keyframes  ball-clip-rotate-pulse-rotate {
        0% {
        -webkit-transform: translate(-50%, -50%) rotate(0deg);
        -moz-transform: translate(-50%, -50%) rotate(0deg);
            -o-transform: translate(-50%, -50%) rotate(0deg);
                transform: translate(-50%, -50%) rotate(0deg);
        }
        50% {
        -webkit-transform: translate(-50%, -50%) rotate(180deg);
        -moz-transform: translate(-50%, -50%) rotate(180deg);
            -o-transform: translate(-50%, -50%) rotate(180deg);
                transform: translate(-50%, -50%) rotate(180deg);
        }
        100% {
        -webkit-transform: translate(-50%, -50%) rotate(360deg);
        -moz-transform: translate(-50%, -50%) rotate(360deg);
            -o-transform: translate(-50%, -50%) rotate(360deg);
                transform: translate(-50%, -50%) rotate(360deg);
        }
        }
        @-webkit-keyframes ball-clip-rotate-pulse-scale {
        0%,
        100% {
        opacity: 1;
        -webkit-transform: translate(-50%, -50%) scale(1);
                transform: translate(-50%, -50%) scale(1);
        }
        30% {
        opacity: .3;
        -webkit-transform: translate(-50%, -50%) scale(.15);
                transform: translate(-50%, -50%) scale(.15);
        }
        }
        @-moz-keyframes ball-clip-rotate-pulse-scale {
        0%,
        100% {
        opacity: 1;
        -moz-transform: translate(-50%, -50%) scale(1);
            transform: translate(-50%, -50%) scale(1);
        }
        30% {
        opacity: .3;
        -moz-transform: translate(-50%, -50%) scale(.15);
            transform: translate(-50%, -50%) scale(.15);
        }
        }
        @-o-keyframes ball-clip-rotate-pulse-scale {
        0%,
        100% {
        opacity: 1;
        -o-transform: translate(-50%, -50%) scale(1);
        transform: translate(-50%, -50%) scale(1);
        }
        30% {
        opacity: .3;
        -o-transform: translate(-50%, -50%) scale(.15);
        transform: translate(-50%, -50%) scale(.15);
        }
        }
        @keyframes  ball-clip-rotate-pulse-scale {
        0%,
        100% {
        opacity: 1;
        -webkit-transform: translate(-50%, -50%) scale(1);
        -moz-transform: translate(-50%, -50%) scale(1);
            -o-transform: translate(-50%, -50%) scale(1);
                transform: translate(-50%, -50%) scale(1);
        }
        30% {
        opacity: .3;
        -webkit-transform: translate(-50%, -50%) scale(.15);
        -moz-transform: translate(-50%, -50%) scale(.15);
            -o-transform: translate(-50%, -50%) scale(.15);
                transform: translate(-50%, -50%) scale(.15);
        }
        }
</style>
</head>

<body>


    <div id="Wrapper">
        <div class="uk-container">
             <img class="" src="assets/gc app logo.png" style="width: 100%" alt="">
            <div class="uk-width-1-3@m m-auto my-16">
                <div class="mb-4">
                    <h2 >Follow the following<span class="uk-text-bold"> Steps</span></h2>                    
                </div>

                <div class="m-auto mb-10 uk-width" style="color: rgb(21, 109, 4);">
                    <p>1st - Register to have your account ready</p>
                    <p>2nd - Use correct Id-number and password to login</p>
                    <p>3rd - Login and send your lastword to the comitee</p>
                </div>

              
                
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('register', [])->html();
} elseif ($_instance->childHasBeenRendered('9wkYzF9')) {
    $componentId = $_instance->getRenderedChildComponentId('9wkYzF9');
    $componentTag = $_instance->getRenderedChildComponentTagName('9wkYzF9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9wkYzF9');
} else {
    $response = \Livewire\Livewire::mount('register', []);
    $html = $response->html();
    $_instance->logRenderedChild('9wkYzF9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
               

                <div class="mb-4">
                    <h6>Form built by<span class="uk-text-bold"> TECHINO CLUB </span> GC-2013</h6>
                </div>
            </div>



        </div>

        

        <!-- Content / End -->

    </div>

<?php echo \Livewire\Livewire::scripts(); ?>



<!-- Scripts
    ================================================== -->
    <script src="assets/js/tippy.all.min.js"></script>  
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/uikit.js"></script>
    <script src="assets/js/simplebar.min.js"></script>
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/bootstrap-select.min.js"></script>
</body>


<!-- Mirrored from demo.holathemes.com/coursterhtml/form-register.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 04 May 2021 17:42:42 GMT -->
</html><?php /**PATH C:\Users\Net\Desktop\gc2013form\resources\views/welcome.blade.php ENDPATH**/ ?>