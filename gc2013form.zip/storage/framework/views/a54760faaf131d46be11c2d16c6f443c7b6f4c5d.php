

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <!-- Basic Page Needs
    ================================================== -->
    <title>GC-2013</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Wollo university KIOT GC-2013">
    <!-- Favicon -->
    <link href="assets/images/favicon.png" rel="icon" type="image/png">
    <!-- CSS 
    ================================================== -->
    <link rel="stylesheet" href="assets/css/uikit.css">
    <link rel="stylesheet" href="assets/css/tailwind.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/toast.css">
        <script src="assets/js/toast.js"></script>
    <!-- icons
    ================================================== -->
    <link rel="stylesheet" href="assets/css/icons.css">
 <?php echo \Livewire\Livewire::styles(); ?>

    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.8.2/dist/alpine.min.js" defer></script>
<style>
    [x-cloak] {
        display: none !important;
    }
</style>
</head>
<body>
    <div id="Wrapper">
        <div class="uk-container">
             <img class="" src="assets/gc app logo.png" style="width: 100%" alt="">
             
             <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('datatable', ['model' => 'App\Models\User','include' => 'id,full_name,kiot_id,lastword,dept,phone','searchable' => 'full_name, kiot_id','exclude' => 'updated_at','exportable' => true])->html();
} elseif ($_instance->childHasBeenRendered('MaYjdJb')) {
    $componentId = $_instance->getRenderedChildComponentId('MaYjdJb');
    $componentTag = $_instance->getRenderedChildComponentTagName('MaYjdJb');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('MaYjdJb');
} else {
    $response = \Livewire\Livewire::mount('datatable', ['model' => 'App\Models\User','include' => 'id,full_name,kiot_id,lastword,dept,phone','searchable' => 'full_name, kiot_id','exclude' => 'updated_at','exportable' => true]);
    $html = $response->html();
    $_instance->logRenderedChild('MaYjdJb', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
             
              <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <a href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault();
                    this.closest('form').submit();">
                    <?php echo e(__('Log Out')); ?>

                    </a>
              </form>
              
            <div class="uk-width-1-3@m m-auto my-16">
               
                
                <div class="mb-4">
                    <h6>Form built by<span class="uk-text-bold"> TECHINO CLUB </span> GC-2013</h6>
                </div>
            </div>



        </div>

        

        <!-- Content / End -->

    </div>

<?php echo \Livewire\Livewire::scripts(); ?>



<!-- Scripts
    ================================================== -->
    <script src="assets/js/tippy.all.min.js"></script>  
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/uikit.js"></script>
    <script src="assets/js/simplebar.min.js"></script>
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/bootstrap-select.min.js"></script>
</body>

</html><?php /**PATH C:\Users\Net\Desktop\gc2013form\resources\views/admin.blade.php ENDPATH**/ ?>